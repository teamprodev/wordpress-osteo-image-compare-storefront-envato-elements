<?php

namespace Osteo_Image_Compare\Widgets;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Widget_Base;

defined( 'ABSPATH' ) || die();

class Osteo_Image_Compare extends Widget_Base {

    public function get_name() {
        return "Osteo_Image_Compare";
    }

    public function get_title() {
        return esc_html__( "Osteo Image Compare", 'osteo-image-compare' );
    }

    public function get_icon() {
        return 'eicon-image-before-after';
    }

    public function get_keywords() {
        return ['image-compare', 'image', 'compare'];
    }

    public function get_categories() {
        return array( 'basic' );
    }

    protected function register_controls() {

        $this->start_controls_section(
            'content',
            [
                'label' => esc_html__( 'Image', 'osteo-image-compare' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->start_controls_tabs( 'tabs_content_field' );

        $this->start_controls_tab(
            'before_tab',
            [
                'label' => esc_html__( 'Before', 'osteo-image-compare' ),
            ]
        );

        $this->add_control(
            'before_image',
            [
                'label'   => esc_html__( 'Choose Image', 'osteo-image-compare' ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'before_label',
            [
                'label'   => esc_html__( 'Before Label', 'osteo-image-compare' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Original',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'after_tab',
            [
                'label' => esc_html__( 'After', 'osteo-image-compare' ),
            ]
        );

        $this->add_control(
            'after_image',
            [
                'label'   => esc_html__( 'Choose Image', 'osteo-image-compare' ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'after_label',
            [
                'label'   => esc_html__( 'After Label', 'osteo-image-compare' ),
                'type'    => \Elementor\Controls_Manager::TEXT,
                'default' => 'Modified',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
			\Elementor\Group_Control_Image_Size::get_type(),
			[
				'name' => 'thumbnail',
                'default' => 'full',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'settings',
            [
                'label' => esc_html__( 'Settings', 'osteo-image-compare' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'orientation',
            [
                'label'   => esc_html__( 'Orientation', 'osteo-image-compare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'horizontal',
                'options' => [
                    'horizontal' => esc_html__( 'Horizontal', 'osteo-image-compare' ),
                    'vertical'   => esc_html__( 'Vertical', 'osteo-image-compare' ),
                ],
            ]
        );

        $this->add_control(
            'no_overlay',
            [
                'label'   => esc_html__( 'No Overlay', 'osteo-image-compare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true'  => esc_html__( 'True', 'osteo-image-compare' ),
                    'false' => esc_html__( 'False', 'osteo-image-compare' ),
                ],
            ]
        );

        $this->add_control(
            'move_slider_on_hover',
            [
                'label'   => esc_html__( 'Hover', 'osteo-image-compare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true'  => esc_html__( 'True', 'osteo-image-compare' ),
                    'false' => esc_html__( 'False', 'osteo-image-compare' ),
                ],
            ]
        );

        $this->add_control(
            'move_with_handle_only',
            [
                'label'   => esc_html__( 'Move Handle', 'osteo-image-compare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true'  => esc_html__( 'True', 'osteo-image-compare' ),
                    'false' => esc_html__( 'False', 'osteo-image-compare' ),
                ],
            ]
        );

        $this->add_control(
            'click_to_move',
            [
                'label'   => esc_html__( 'Click to Move', 'osteo-image-compare' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true'  => esc_html__( 'True', 'osteo-image-compare' ),
                    'false' => esc_html__( 'False', 'osteo-image-compare' ),
                ],
            ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
            'content_styles',
            [
                'label' => esc_html__( 'Content', 'osteo-image-compare' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'before_label_options',
            [
                'label' => esc_html__( 'Before Label Options', 'osteo-timeline' ),
                'type'  => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'before_label_color',
            [
                'label'     => esc_html__( 'Color', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-before-label:before'  => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'before_label_background',
            [
                'label'     => esc_html__( 'Background', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E91E63',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-before-label:before'  => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'before_label_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 2,
                        'max' => 50,
                    ],
                ],
                'default'   => [
                    'size' => 4,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-before-label:before' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      		=> 'before_label_typography',
                'label'     		=> esc_html__( 'Typography', 'osteo-timeline' ),
                'selector'  		=> '{{WRAPPER}} .twentytwenty-before-label:before',
            ]
        );

		$this->add_control(
			'before_label_padding',
			[
				'label'      		=> esc_html__( 'Padding', 'osteo-timeline' ),
				'type'       		=> Controls_Manager::DIMENSIONS,
				'size_units' 		=> [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .twentytwenty-before-label:before' 	=> 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
            'after_label_options',
            [
                'label' => esc_html__( 'After Label Options', 'osteo-timeline' ),
                'type'  => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'after_label_color',
            [
                'label'     => esc_html__( 'Color', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-after-label:before'  => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'after_label_background',
            [
                'label'     => esc_html__( 'Background', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E91E63',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-after-label:before'  => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'after_label_border_radius',
            [
                'label'     => esc_html__( 'Border Radius', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 2,
                        'max' => 50,
                    ],
                ],
                'default'   => [
                    'size' => 4,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-after-label:before' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      		=> 'after_label_typography',
                'label'     		=> esc_html__( 'Typography', 'osteo-timeline' ),
                'selector'  		=> '{{WRAPPER}} .twentytwenty-after-label:before',
            ]
        );

		$this->add_control(
			'after_label_padding',
			[
				'label'      		=> esc_html__( 'Padding', 'osteo-timeline' ),
				'type'       		=> Controls_Manager::DIMENSIONS,
				'size_units' 		=> [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .twentytwenty-after-label:before' 	=> 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'handler_styles',
            [
                'label' => esc_html__( 'Handler', 'osteo-image-compare' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => esc_html__( 'Color', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E91E63',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-left-arrow'  => 'border-right-color: {{VALUE}};',
                    '{{WRAPPER}} .twentytwenty-right-arrow' => 'border-left-color: {{VALUE}};',
                    '{{WRAPPER}} .twentytwenty-down-arrow'  => 'border-top-color: {{VALUE}};',
                    '{{WRAPPER}} .twentytwenty-up-arrow'  => 'border-bottom-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'handler_border',
            [
                'label'     => esc_html__( 'Border', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 2,
                        'max' => 20,
                    ],
                ],
                'default'   => [
                    'size' => 2,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-handle' => 'border: {{SIZE}}{{UNIT}} solid;',
                ],
            ]
        );

        $this->add_control(
            'handler_border_color',
            [
                'label'     => esc_html__( 'Border Color', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E91E63',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-handle'  => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'handler_line_height',
            [
                'label'     => esc_html__( 'Line Height', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 2,
                        'max' => 20,
                    ],
                ],
                'default'   => [
                    'size' => 2,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-vertical .twentytwenty-handle:before' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .twentytwenty-vertical .twentytwenty-handle:after' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'orientation' 	=> 'vertical',
                ],
            ]
        );

        $this->add_control(
            'handler_line_height_color',
            [
                'label'     => esc_html__( 'Line Height Color', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E91E63',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-vertical .twentytwenty-handle:before'  => 'background: {{VALUE}}!important;',
                    '{{WRAPPER}} .twentytwenty-vertical .twentytwenty-handle:after'  => 'background: {{VALUE}}!important;',
                ],
                'condition' => [
                    'orientation' 	=> 'vertical',
                ],
            ]
        );

        $this->add_control(
            'handler_line_width',
            [
                'label'     => esc_html__( 'Line Width', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 2,
                        'max' => 20,
                    ],
                ],
                'default'   => [
                    'size' => 2,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-horizontal .twentytwenty-handle:before' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .twentytwenty-horizontal .twentytwenty-handle:after' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'orientation' 	=> 'horizontal',
                ],
            ]
        );

        $this->add_control(
            'handler_line_width_color',
            [
                'label'     => esc_html__( 'Line Width Color', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E91E63',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-horizontal .twentytwenty-handle:before'  => 'background: {{VALUE}}!important;',
                    '{{WRAPPER}} .twentytwenty-horizontal .twentytwenty-handle:after'  => 'background: {{VALUE}}!important;',
                ],
                'condition' => [
                    'orientation' 	=> 'horizontal',
                ],
            ]
        );

        $this->add_control(
            'handler_border_color',
            [
                'label'     => esc_html__( 'Border Color', 'osteo-image-compare' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#E91E63',
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-handle'  => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'handler_width',
            [
                'label'     => esc_html__( 'Width', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default'   => [
                    'size' => 38,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-handle' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'handler_height',
            [
                'label'     => esc_html__( 'Height', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 100,
                    ],
                ],
                'default'   => [
                    'size' => 38,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-handle' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'handler_margin_top',
            [
                'label'     => esc_html__( 'Margin Top', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 150,
                    ],
                ],
                'default'   => [
                    'size' => 22,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-horizontal .twentytwenty-handle:after' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'orientation' 	=> 'horizontal',
                ],
            ]
        );

        $this->add_control(
            'handler_margin_bottom',
            [
                'label'     => esc_html__( 'Margin Bottom', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 150,
                    ],
                ],
                'default'   => [
                    'size' => 25,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-horizontal .twentytwenty-handle:before' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'orientation' 	=> 'horizontal',
                ],
            ]
        );

        $this->add_control(
            'handler_margin_left',
            [
                'label'     => esc_html__( 'Margin Left', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 150,
                    ],
                ],
                'default'   => [
                    'size' => 22,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-vertical .twentytwenty-handle:before' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'orientation' 	=> 'vertical',
                ],
            ]
        );

        $this->add_control(
            'handler_margin_right',
            [
                'label'     => esc_html__( 'Margin Right', 'osteo-image-compare' ),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'max' => 150,
                    ],
                ],
                'default'   => [
                    'size' => 22,
                ],
                'selectors' => [
                    '{{WRAPPER}} .twentytwenty-vertical .twentytwenty-handle:after' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'orientation' 	=> 'vertical',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $orientation = $this->get_settings( 'orientation' );
        $before_label = $this->get_settings( 'before_label' );
        $after_label = $this->get_settings( 'after_label' );
        $no_overlay = $this->get_settings( 'no_overlay' );
        $no_overlay = $this->get_settings( 'no_overlay' );
        $move_slider_on_hover = $this->get_settings( 'move_slider_on_hover' );
        $move_with_handle_only = $this->get_settings( 'move_with_handle_only' );
        $click_to_move = $this->get_settings( 'click_to_move' );

        
        $this->add_render_attribute( 'before_image', 'src', $settings['before_image']['url'] );
        $this->add_render_attribute( 'before_image', 'alt', Control_Media::get_image_alt( $settings['before_image'] ) );
        $this->add_render_attribute( 'before_image', 'title', Control_Media::get_image_title( $settings['before_image'] ) );

        $this->add_render_attribute( 'after_image', 'src', $settings['after_image']['url'] );
        $this->add_render_attribute( 'after_image', 'alt', Control_Media::get_image_alt( $settings['after_image'] ) );
        $this->add_render_attribute( 'after_image', 'title', Control_Media::get_image_title( $settings['after_image'] ) );

        ?>



        <div class="twentytwenty-container" data-orientation="<?php echo esc_attr( $settings['orientation'] ); ?>" data-before_label="<?php echo esc_attr( $settings['before_label'] ); ?>" data-after_label="<?php echo esc_attr( $settings['after_label'] ); ?>" data-no_overlay="<?php echo esc_attr( $settings['no_overlay'] ); ?>" data-move_slider_on_hover="<?php echo esc_attr( $settings['move_slider_on_hover'] ); ?>" data-move_with_handle_only="<?php echo esc_attr( $settings['move_with_handle_only'] ); ?>" data-click_to_move="<?php echo esc_attr( $settings['click_to_move'] ); ?>">
            <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'before_image' ); ?>
            <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'thumbnail', 'after_image' ); ?>
        </div>

		<?php
}
}