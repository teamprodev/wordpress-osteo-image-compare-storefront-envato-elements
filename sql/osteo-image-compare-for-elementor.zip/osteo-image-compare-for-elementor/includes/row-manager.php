<?php

namespace Osteo_Image_Compare;
defined( 'ABSPATH' ) || die();

add_filter ( 'plugin_action_links_'.OSTEO_IMAGE_COMPARE_PLUGIN_BASE, function( $links ) {
    $link = sprintf( "<a href='%s' style='color: #E91E63; font-weight: 700'>%s</a>", esc_url( 'https://docs.twinkletheme.com/docs/osteo-flip-book-for-elementor/installation/'), esc_html__('Documentation', 'osteo-image-compare'));
    array_push( $links, $link );
    
    return $links;
});