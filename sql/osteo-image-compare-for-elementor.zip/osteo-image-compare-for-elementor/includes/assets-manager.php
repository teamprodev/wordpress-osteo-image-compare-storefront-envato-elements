<?php

namespace Osteo_Image_Compare;
defined( 'ABSPATH' ) || die();

if ( !class_exists( 'Assets_Manager' ) ) {

    class Assets_Manager {

        private static $_instance = null;
        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        public function __construct() {
            add_action( "elementor/frontend/after_enqueue_styles", [$this, 'frontend_enqueue_styles'] );
            add_action( 'elementor/frontend/after_enqueue_scripts', [$this, 'frontend_enqueue_scripts'] );
        }

        public function frontend_enqueue_styles() {

            wp_enqueue_style( 'twentytwenty', OSTEO_IMAGE_COMPARE_ASSETS . 'vendor/twentytwenty/twentytwenty.css' );

        }

        public function frontend_enqueue_scripts() {

            wp_enqueue_script( 'twentytwenty-event-move', OSTEO_IMAGE_COMPARE_ASSETS . 'vendor/twentytwenty/jquery.event.move.js', array( 'jquery' ), '2.0.0', true );
            wp_enqueue_script( 'twentytwenty', OSTEO_IMAGE_COMPARE_ASSETS . 'vendor/twentytwenty/jquery.twentytwenty.js', array( 'jquery' ), '1.0.0', true );
            wp_enqueue_script( 'osteo-image-compare', OSTEO_IMAGE_COMPARE_ASSETS . 'js/main.js', array( 'jquery' ), '1.0.0', true );

        }

    }

    Assets_Manager::instance();

}